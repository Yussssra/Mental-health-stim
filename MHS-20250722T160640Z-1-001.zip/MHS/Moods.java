package MHS;
import java.util.*;

enum moodVariation{
    joy(1),
    sadness(-1),
    anger(-2),
    fear(-3),
    surprise(-4),
    disgust(-5),
    calm(2);

    final int value;
    moodVariation(int value){
        this.value = value;
    }

}
public class Moods {
    public final ArrayList<String> moodList;

    Moods(){
        moodList = new ArrayList<>();
        moodList.add("joy");
        moodList.add("sadness");
        moodList.add("anger");
        moodList.add("fear");
        moodList.add("surprise");
        moodList.add("disgust");
        moodList.add("calm");
    }
}
