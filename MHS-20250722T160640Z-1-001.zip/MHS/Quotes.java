package MHS;
import java.util.*;

public class Quotes {
    private final String[] quotes = {"Believe you can and you're halfway there.",
            "Success is not final, failure is not fatal: It is the courage to continue that counts.",
            "Don't watch the clock; do what it does. Keep going.",
            "The harder you work for something, the greater you'll feel when you achieve it.",
            "Push yourself, because no one else is going to do it for you.",
            "Dream it. Wish it. Do it.",
            "Great things never come from comfort zones.",
            "Success doesn’t just find you. You have to go out and get it.",
            "The key to success is to focus on goals, not obstacles.",
            "Don’t stop when you’re tired. Stop when you’re done.",
            "It’s going to be hard, but hard does not mean impossible.",
            "Wake up with determination. Go to bed with satisfaction.",
            "Do something today that your future self will thank you for.",
            "Little things make big days.",
            "Don’t wait for opportunity. Create it.",
            "Sometimes we’re tested not to show our weaknesses, but to discover our strengths.",
            "The only limit to our realization of tomorrow is our doubts of today.",
            "Discipline is the bridge between goals and accomplishment.",
            "The way to get started is to quit talking and begin doing.",
            "Your limitation it’s only your imagination.",
            "Sometimes later becomes never. Do it now.",
            "Stay positive, work hard, make it happen.",
            "Dream bigger. Do bigger.",
            "Don’t be afraid to give up the good to go for the great.",
            "Act as if what you do makes a difference. It does.",
            "Start where you are. Use what you have. Do what you can.",
            "Failure is not the opposite of success, it’s part of success.",
            "You are capable of amazing things.",
            "Don’t limit your challenges. Challenge your limits.",
            "Hard work beats talent when talent doesn’t work hard."};

    public String getQuote(){
        Random rand = new Random();
        return quotes[rand.nextInt(quotes.length)];

    }
}
