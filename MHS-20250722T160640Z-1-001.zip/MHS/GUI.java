package MHS;
import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;

public class GUI extends JFrame {

    private final JTextField nameField;
    private final JPanel moodPanel;
    private final JLabel welcomeLabel, suggestionLabel, activityLabel, quoteLabel, usernameLabel;
    private String userName;
    private final initCheck appCore;

    public GUI() {
        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
        } catch (Exception ignored) {}

        appCore = new initCheck();

        setTitle("Mental Health Simulator");
        setSize(600, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(58, 98, 214));

        setLayout(new BorderLayout());

        JPanel headPanel = new JPanel();
        headPanel.setLayout(new BoxLayout(headPanel, BoxLayout.Y_AXIS));
        headPanel.setOpaque(false);
        headPanel.setBorder(new EmptyBorder(30, 40, 20, 40));

        welcomeLabel = new JLabel("Hey there! What is your name?", SwingConstants.CENTER);
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setBorder(new EmptyBorder(0, 0, 25, 0));

        JPanel inputContainer = new JPanel();
        inputContainer.setLayout(new BoxLayout(inputContainer, BoxLayout.Y_AXIS));
        inputContainer.setOpaque(false);

        inputContainer.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(200, 200, 200, 100), 2, true),
                new EmptyBorder(25, 30, 25, 30)
        ));

        usernameLabel = new JLabel("Enter Username:", SwingConstants.CENTER);
        usernameLabel.setForeground(new Color(240, 248, 255));
        usernameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        usernameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        usernameLabel.setBorder(new EmptyBorder(0, 0, 15, 0));

        nameField = new JTextField(20);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        nameField.setMargin(new Insets(12, 15, 12, 15));
        nameField.setMaximumSize(new Dimension(300, 45));
        nameField.setPreferredSize(new Dimension(300, 45));
        nameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createRaisedBevelBorder(),
                new EmptyBorder(8, 12, 8, 12)
        ));

        JButton submitBtn = createAnimatedButton("Continue");
        submitBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        submitBtn.setPreferredSize(new Dimension(200, 50));
        submitBtn.setMaximumSize(new Dimension(200, 50));
        submitBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        inputContainer.add(usernameLabel);
        inputContainer.add(nameField);
        inputContainer.add(Box.createVerticalStrut(20));
        inputContainer.add(submitBtn);

        headPanel.add(welcomeLabel);
        headPanel.add(inputContainer);

        add(headPanel, BorderLayout.NORTH);

        moodPanel = new JPanel();
        moodPanel.setOpaque(false);
        moodPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 16, 12));
        moodPanel.setBorder(new EmptyBorder(20, 20, 10, 20));
        moodPanel.setVisible(false);

        JPanel centerWrap = new JPanel(new BorderLayout());
        centerWrap.setOpaque(false);
        centerWrap.setBorder(new EmptyBorder(10, 0, 0, 0));

        suggestionLabel = new JLabel("", SwingConstants.CENTER);
        suggestionLabel.setForeground(new Color(245, 245, 245));
        suggestionLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        suggestionLabel.setBorder(new EmptyBorder(0, 0, 20, 0));

        centerWrap.add(suggestionLabel, BorderLayout.NORTH);
        centerWrap.add(moodPanel, BorderLayout.CENTER);

        add(centerWrap, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBorder(new EmptyBorder(15, 30, 25, 30));

        activityLabel = new JLabel("", SwingConstants.CENTER);
        activityLabel.setFont(new Font("Segoe UI", Font.BOLD, 19));
        activityLabel.setForeground(new Color(255, 235, 59)); // Brighter yellow
        activityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        activityLabel.setBorder(new EmptyBorder(10, 0, 15, 0));

        quoteLabel = new JLabel("", SwingConstants.CENTER);
        quoteLabel.setFont(new Font("Georgia", Font.ITALIC, 16)); // Changed to Georgia for elegance
        quoteLabel.setForeground(new Color(230, 230, 250)); // Lavender color
        quoteLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        bottomPanel.add(activityLabel);
        bottomPanel.add(quoteLabel);

        add(bottomPanel, BorderLayout.SOUTH);

        submitBtn.addActionListener(e -> {
            userName = nameField.getText().trim();
            if (!userName.isEmpty()) {
                appCore.classUser = new User(userName);

                // Smooth transition effect
                welcomeLabel.setText("Hello, " + userName + "!");
                welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));

                inputContainer.setVisible(false);
                suggestionLabel.setText("How are you feeling today?");
                loadMoodButtons();
                moodPanel.setVisible(true);

                revalidate();
                repaint();
            } else {
                nameField.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
                Timer timer = new Timer(2000, evt -> {
                    nameField.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createRaisedBevelBorder(),
                            new EmptyBorder(8, 12, 8, 12)
                    ));
                });
                timer.setRepeats(false);
                timer.start();
            }
        });
    }

    private void loadMoodButtons() {
        moodPanel.removeAll();
        String[] moods = appCore.classMood.moodList.toArray(new String[0]);

        Color[] gradientColors = {
                new Color(255,193,7),     // joy - gold
                new Color(76,175,80),     // calm - green
                new Color(33,150,243),    // sadness - blue
                new Color(244,67,54),     // anger - red
                new Color(156,39,176),    // fear - purple
                new Color(255,152,0),     // surprise - orange
                new Color(121,85,72)      // disgust - brown
        };

        for (int i = 0; i < moods.length; i++) {
            String mood = moods[i];
            JButton btn = createAnimatedButton(mood.substring(0,1).toUpperCase()+mood.substring(1));
            btn.setBackground(gradientColors[i]);
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("Segoe UI", Font.BOLD, 17));
            btn.setPreferredSize(new Dimension(120, 50));
            btn.setFocusPainted(false);
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btn.setBorder(BorderFactory.createRaisedBevelBorder());

            btn.addActionListener(evt -> {
                animateButtonSelection(btn);
                onMoodChosen(mood);
            });
            moodPanel.add(btn);
        }
    }

    private void onMoodChosen(String mood) {
        appCore.classUser.moodHistory.add(mood);
        int moodNum = moodVariation.valueOf(mood).value;
        String activity = appCore.classActivity.getActivity(moodNum);

        activityLabel.setText("<html><div style='text-align: center;'><b>Based on your mood, try:</b><br/>" +
                "<span style='color: #FFE135;'>" + activity + "</span></div></html>");

        String quote = appCore.classQuote.getQuote();
        quoteLabel.setText("<html><div style='text-align: center; font-family: Georgia; font-style: italic;'>" +
                "<span style='color: #E6E6FA; font-size: 16px;'>💭 Motivation</span><br/>" +
                "<span style='color: #F0E68C; font-size: 15px;'>\"" + quote + "\"</span></div></html>");
    }

    private void animateButtonSelection(JButton btn) {
        Color originalColor = btn.getBackground();
        btn.setBackground(originalColor.brighter());

        Timer timer = new Timer(150, e -> btn.setBackground(originalColor));
        timer.setRepeats(false);
        timer.start();
    }

    private JButton createAnimatedButton(String text) {
        JButton button = new JButton(text);
        button.setContentAreaFilled(true);
        button.setBorderPainted(true);
        button.setOpaque(true);
        button.setBackground(new Color(117, 81, 255));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createRaisedBevelBorder());

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(button.getBackground().brighter());
                button.setBorder(BorderFactory.createLoweredBevelBorder());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(117, 81, 255));
                button.setBorder(BorderFactory.createRaisedBevelBorder());
            }
        });
        return button;
    }

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        SwingUtilities.invokeLater(() -> new GUI().setVisible(true));
    }
}
