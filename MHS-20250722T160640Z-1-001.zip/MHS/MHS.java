package MHS;
import java.util.*;

class initCheck {

    // Reset
    public static final String RESET = "\u001B[0m";

    // Bold and Italic
    public static final String BOLD = "\u001B[1m";
    public static final String DIM = "\u001B[2m";
    public static final String ITALIC = "\u001B[3m"; // Not supported in all terminals
    public static final String UNDERLINE = "\u001B[4m";
    public static final String STRIKETHROUGH = "\u001B[9m";

    // Regular Colors
    public static final String RED = "\u001B[31m";
    public static final String YELLOW = "\u001B[33m";

    // Bright Colors (lighter shades)
    public static final String BRIGHT_BLACK = "\u001B[90m";   // Gray
    public static final String BRIGHT_RED = "\u001B[91m";
    public static final String BRIGHT_GREEN = "\u001B[92m";
    public static final String BRIGHT_YELLOW = "\u001B[93m";
    public static final String BRIGHT_BLUE = "\u001B[94m";
    public static final String BRIGHT_PURPLE = "\u001B[95m";
    public static final String BRIGHT_CYAN = "\u001B[96m";
    public static final String BRIGHT_WHITE = "\u001B[97m";


    User classUser;
    Quotes classQuote;
    Moods classMood;
    Activity classActivity;

    initCheck() {
        classQuote = new Quotes();
        classMood = new Moods();
        classActivity = new Activity();
    }

    void createUser(Scanner input) {
        // Clear screen
        System.out.print("\u001B[H\u001B[2J");
        System.out.flush();

        System.out.println(BRIGHT_CYAN + """
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
""" + BRIGHT_PURPLE + BOLD +
                "║            Welcome to the Mental Health Simulator            ║\n" +
                BRIGHT_CYAN + """
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
""" + BRIGHT_WHITE + BOLD);

        System.out.print("\nLet's begin your journey to feeling better!\n");
        System.out.print("Please enter your " + BRIGHT_BLUE + "NAME" + BRIGHT_WHITE + BOLD + " so we can personalize your experience: " + BRIGHT_BLUE);

        String name = input.nextLine().trim();
        classUser = new User(name);

        System.out.println(BRIGHT_WHITE + BOLD + "\nHi " + BRIGHT_BLUE + name + BRIGHT_WHITE + BOLD +"!  We are here for you.");
    }

    void start(Scanner input) {
        String currentMood = "NONE";

        // ASCII mood header
        System.out.println(BRIGHT_GREEN + BOLD + ITALIC + UNDERLINE + "\nMOOD CHECK-IN\n" + RESET + BRIGHT_WHITE + BOLD);

        System.out.println("How are you feeling right now?");
        System.out.print("\nOne of these? : [ ");
        for (String mood : classMood.moodList) {
            System.out.print(BRIGHT_BLUE + mood.toUpperCase() + " " + BRIGHT_GREEN);
        }
        System.out.print("]\n");

        System.out.print(BRIGHT_WHITE + BOLD +  "Type your current mood: " + BRIGHT_BLUE);
        while (!(classMood.moodList.contains(currentMood))) {
            currentMood = input.nextLine().toLowerCase().trim();
            if (!classMood.moodList.contains(currentMood)) {
                System.out.print(BRIGHT_RED + "❌ Hmm, I didn't catch that. Please choose a mood from the list above: " + BRIGHT_BLUE);
            }
        }

        classUser.moodHistory.add(currentMood);

        // Activity header
        System.out.println(BRIGHT_GREEN + ITALIC + UNDERLINE + "\nGENERATING SUGGESTIONS TO HELP YOUR MOOD\n" + RESET);

        String suggestion = classActivity.getActivity(moodVariation.valueOf(currentMood).value);

        System.out.println(BRIGHT_YELLOW + "Based on your mood, here's something you can try:");
        System.out.println();
        System.out.println(BRIGHT_CYAN + "Suggestion: " + BRIGHT_BLUE + suggestion);
        System.out.print(BRIGHT_CYAN + "Some Motivation: " + BRIGHT_BLUE);
        System.out.println(BRIGHT_BLUE + classQuote.getQuote() + BRIGHT_WHITE  + BOLD);
        System.out.println(RESET);
    }
}

public class MHS {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        initCheck first = new initCheck();
        first.createUser(input);
        first.start(input);
    }
}