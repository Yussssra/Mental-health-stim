package MHS;
import java.util.*;

public class Activity {

    String[] joyActivities = {
            "Dancing to upbeat music",
            "Singing your favorite songs",
            "Spending time with loved ones",
            "Playing a fun game",
            "Watching a comedy show",
            "Going on a picnic",
            "Doing something creative like painting",
            "Sharing good news with a friend",
            "Taking a nature walk",
            "Writing in a gratitude journal"
    };

    String[] sadnessActivities = {
            "Listening to calming music",
            "Talking to a trusted friend",
            "Writing your thoughts in a journal",
            "Watching a comforting movie",
            "Taking a warm bath",
            "Doing light exercise like walking",
            "Reading an inspiring book",
            "Practicing deep breathing",
            "Drawing or coloring",
            "Spending time with pets"
    };

    String[] angerActivities = {
            "Punching a pillow",
            "Going for a run or brisk walk",
            "Writing an angry letter and tearing it up",
            "Listening to loud music",
            "Doing strength training exercises",
            "Practicing deep breathing or meditation",
            "Drawing or painting your emotions",
            "Screaming into a pillow",
            "Journaling what triggered you",
            "Cleaning your room aggressively"
    };

    String[] fearActivities = {
            "Practicing grounding techniques (5-4-3-2-1)",
            "Talking to someone you trust",
            "Doing deep breathing exercises",
            "Watching a comforting show",
            "Writing down your fears and countering them",
            "Holding a comforting object",
            "Listening to soothing music",
            "Doing a small act of bravery",
            "Visualization of a safe space",
            "Doing yoga or stretching"
    };

    String[] surpriseActivities = {
            "Calling a friend to share the moment",
            "Writing about the surprise in a journal",
            "Taking a picture or video",
            "Reflecting on what you’ve learned",
            "Creating something inspired by the surprise",
            "Sharing it on social media",
            "Smiling or laughing out loud",
            "Taking a walk to process it",
            "Making a list of related surprises",
            "Expressing gratitude for the experience"
    };

    String[] disgustActivities = {
            "Taking a shower or washing hands",
            "Venting to a friend",
            "Journaling what made you feel disgusted",
            "Cleaning your space",
            "Watching something light-hearted",
            "Practicing mindfulness to let go",
            "Taking deep breaths",
            "Chewing mint or brushing teeth",
            "Walking in fresh air",
            "Listening to calming music"
    };

    String[] calmActivities = {
            "Meditating in silence",
            "Listening to soft instrumental music",
            "Doing yoga or light stretches",
            "Drinking herbal tea",
            "Watching clouds or nature",
            "Reading a peaceful book",
            "Doing mindful breathing",
            "Journaling positive thoughts",
            "Drawing mandalas",
            "Sitting in a cozy corner with dim lights"
    };

    public String getActivity(int var) {
        Random rand = new Random();
        switch (var) {
            case 1:
                return joyActivities[rand.nextInt(joyActivities.length)];

            case 2:
                return calmActivities[rand.nextInt(calmActivities.length)];

            case -1:
                return sadnessActivities[rand.nextInt(sadnessActivities.length)];

            case -2:
                return angerActivities[rand.nextInt(angerActivities.length)];

            case -3:
                return fearActivities[rand.nextInt(fearActivities.length)];

            case -4:
                return surpriseActivities[rand.nextInt(surpriseActivities.length)];

            case -5:
                return disgustActivities[rand.nextInt(disgustActivities.length)];
            default:
                return ("Unexpected value: " + var);
        }
    }
}