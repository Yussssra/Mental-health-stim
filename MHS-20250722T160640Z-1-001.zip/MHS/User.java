package MHS;
import java.util.*;

public class User {
    final String name;
    ArrayList<String> moodHistory;

    User(String name){
        this.name = name;
        this.moodHistory = new ArrayList<>();
    }

    String getName(){
        return name;
    }

    ArrayList<String> getMoodHistory(){
        return moodHistory;
    }

    void addMoodHistory(String a){
        moodHistory.add(a);
    }
}
